package com.example.artspaceapp.ui.theme

data class Artwork (
    val titleResourceId: Int,
    val artistResourceId: Int,
    val yearResourceId: Int,
    val imageResourceId: Int
)